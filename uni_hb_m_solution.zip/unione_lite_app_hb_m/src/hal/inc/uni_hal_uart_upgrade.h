#ifndef __UART_UPGRADE_HAL_H__
#define __UART_UPGRADE_HAL_H__

#ifdef  __cplusplus
extern "C" {
#endif//__cplusplus

extern void uni_hal_enable_uart_upgrade(uint8_t is_enable);

#ifdef  __cplusplus
}
#endif//__cplusplus

#endif//__WATCHDOG_HAL_H__
