/*
 * Copyright 2019 Unisound AI Technology Co., Ltd.
 * Author: Hao Peng
 * All Rights Reserved.
 */

#ifndef OSAL_OSAL_ASSERT_H_
#define OSAL_OSAL_ASSERT_H_

#include "osal/osal-types.h"

#if defined(_WIN32) || defined(_WIN64)
#define _WINDOWS
#endif

#ifndef _WINDOWS
#define OSAL_EXPORT __attribute__((visibility("default")))
#else
#ifdef DLL_EXPORT
#define OSAL_EXPORT __declspec(dllexport)
#else
#define OSAL_EXPORT __declspec(dllimport)
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*
 * @Description: assert
 * @Input params:
 * @Output params:
 * @Return:
 */
OSAL_EXPORT void OsalAssert(int32_t expression);

#ifdef __cplusplus
}
#endif

#endif  // OSAL_OSAL_ASSERT_H_
