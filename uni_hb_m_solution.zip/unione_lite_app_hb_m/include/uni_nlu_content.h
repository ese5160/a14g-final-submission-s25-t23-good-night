#ifndef INC_UNI_NLU_CONTENT_H_
#define INC_UNI_NLU_CONTENT_H_

typedef struct {
  uni_u32 key_word_hash_code; /* 存放识别词汇对应的hashcode */
  uni_u8  nlu_content_str_index; /* 存放nlu映射表中的索引，实现多个识别词汇可对应同一个nlu，暂支持256条，如果不够换u16 */
  char    *hash_collision_orginal_str /* 类似Java String equal，当hash发生碰撞时，赋值为识别词汇，否则设置为NULL */;
} uni_nlu_content_mapping_t;

enum {
  eCMD_wakeup_uni,
  eCMD_exitUni,
  eCMD_LEDOne,
  eCMD_LEDTwo,
  eCMD_LEDThree,
  eCMD_TurnOffLED,
  eCMD_CountTime,
  eCMD_Forward,
  eCMD_Backward,
  eCMD_Left,
  eCMD_Right,
  eCMD_Stop,
  eCMD_TimeStop,
  eCMD_volumeUpUni,
  eCMD_volumeDownUni,
  eCMD_volumeMidUni,
  eCMD_volumeMinUni,
  eCMD_volumeMaxUni,
  eCMD_Reset,
};

const char* const g_nlu_content_str[] = {
[eCMD_wakeup_uni] = "{\"asr\":\"你好豆腐\",\"cmd\":\"wakeup_uni\",\"pcm\":\"[103, 104, 105]\"}",
[eCMD_exitUni] = "{\"asr\":\"退下\",\"cmd\":\"exitUni\",\"pcm\":\"[106, 107]\"}",
[eCMD_LEDOne] = "{\"asr\":\"模式一\",\"cmd\":\"LEDOne\",\"pcm\":\"[109]\"}",
[eCMD_LEDTwo] = "{\"asr\":\"模式二\",\"cmd\":\"LEDTwo\",\"pcm\":\"[110]\"}",
[eCMD_LEDThree] = "{\"asr\":\"模式三\",\"cmd\":\"LEDThree\",\"pcm\":\"[111]\"}",
[eCMD_TurnOffLED] = "{\"asr\":\"关闭灯带\",\"cmd\":\"TurnOffLED\",\"pcm\":\"[112]\"}",
[eCMD_CountTime] = "{\"asr\":\"开始计时\",\"cmd\":\"CountTime\",\"pcm\":\"[113]\"}",
[eCMD_Forward] = "{\"asr\":\"前进\",\"cmd\":\"Forward\",\"pcm\":\"[114]\"}",
[eCMD_Backward] = "{\"asr\":\"后退\",\"cmd\":\"Backward\",\"pcm\":\"[115]\"}",
[eCMD_Left] = "{\"asr\":\"左转\",\"cmd\":\"Left\",\"pcm\":\"[116]\"}",
[eCMD_Right] = "{\"asr\":\"右转\",\"cmd\":\"Right\",\"pcm\":\"[117]\"}",
[eCMD_Stop] = "{\"asr\":\"停止\",\"cmd\":\"Stop\",\"pcm\":\"[118]\"}",
[eCMD_TimeStop] = "{\"asr\":\"计时停止\",\"cmd\":\"TimeStop\",\"pcm\":\"[119]\"}",
[eCMD_volumeUpUni] = "{\"asr\":\"增大音量\",\"cmd\":\"volumeUpUni\",\"pcm\":\"[120]\"}",
[eCMD_volumeDownUni] = "{\"asr\":\"减小音量\",\"cmd\":\"volumeDownUni\",\"pcm\":\"[121]\"}",
[eCMD_volumeMidUni] = "{\"asr\":\"中等音量\",\"cmd\":\"volumeMidUni\",\"pcm\":\"[122]\"}",
[eCMD_volumeMinUni] = "{\"asr\":\"最小音量\",\"cmd\":\"volumeMinUni\",\"pcm\":\"[123]\"}",
[eCMD_volumeMaxUni] = "{\"asr\":\"最大音量\",\"cmd\":\"volumeMaxUni\",\"pcm\":\"[124]\"}",
[eCMD_Reset] = "{\"asr\":\"重启\",\"cmd\":\"Reset\",\"pcm\":\"[125]\"}",
};

/*TODO perf sort by hashcode O(logN), now version O(N)*/
const uni_nlu_content_mapping_t g_nlu_content_mapping[] = {
  {2922110124U/*你好豆腐*/, eCMD_wakeup_uni, NULL},
  {1995692716U/*豆腐豆腐*/, eCMD_wakeup_uni, NULL},
  {2497873774U/*退下*/, eCMD_exitUni, NULL},
  {225883702U/*拜拜豆腐*/, eCMD_exitUni, NULL},
  {1903994294U/*豆腐拜拜*/, eCMD_exitUni, NULL},
  {930081235U/*模式一*/, eCMD_LEDOne, NULL},
  {930081309U/*模式二*/, eCMD_LEDTwo, NULL},
  {930081244U/*模式三*/, eCMD_LEDThree, NULL},
  {2506145354U/*关闭灯带*/, eCMD_TurnOffLED, NULL},
  {309816522U/*开始计时*/, eCMD_CountTime, NULL},
  {2392060219U/*前进*/, eCMD_Forward, NULL},
  {2398553638U/*后退*/, eCMD_Backward, NULL},
  {2435286915U/*左转*/, eCMD_Left, NULL},
  {2398733358U/*右转*/, eCMD_Right, NULL},
  {2385116443U/*停止*/, eCMD_Stop, NULL},
  {1942278533U/*计时停止*/, eCMD_TimeStop, NULL},
  {642591547U/*增大音量*/, eCMD_volumeUpUni, NULL},
  {182008939U/*减小音量*/, eCMD_volumeDownUni, NULL},
  {3607692158U/*中等音量*/, eCMD_volumeMidUni, NULL},
  {4177521358U/*最小音量*/, eCMD_volumeMinUni, NULL},
  {268918386U/*最大音量*/, eCMD_volumeMaxUni, NULL},
  {2504725461U/*重启*/, eCMD_Reset, NULL},
};

#endif
