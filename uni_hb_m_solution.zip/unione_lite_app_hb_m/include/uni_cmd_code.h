#ifndef INC_UNI_CMD_CODE_H_
#define INC_UNI_CMD_CODE_H_

typedef struct {
  uni_u8      cmd_code; /* cmd code fro send base on SUCP */
  const char  *cmd_str; /* action string on UDP */;
} cmd_code_map_t;

const cmd_code_map_t g_cmd_code_arry[] = {
  {0x0, "wakeup_uni"},
  {0x1, "exitUni"},
  {0x2, "LEDOne"},
  {0x3, "LEDTwo"},
  {0x4, "LEDThree"},
  {0x5, "TurnOffLED"},
  {0x6, "CountTime"},
  {0x7, "Forward"},
  {0x8, "Backward"},
  {0x9, "Left"},
  {0xa, "Right"},
  {0xb, "Stop"},
  {0xc, "TimeStop"},
  {0xd, "volumeUpUni"},
  {0xe, "volumeDownUni"},
  {0xf, "volumeMidUni"},
  {0x10, "volumeMinUni"},
  {0x11, "volumeMaxUni"},
  {0x12, "Reset"},
};

#endif
